﻿using EDCGadgetsLinkedList;

class Program
{
    static void Main(string[] args)
    {
        CustomLinkedList gadgetsList = new CustomLinkedList();

        // Adding gadgets
        gadgetsList.AddGadget("Smartphone", "Everyday");
        gadgetsList.AddGadget("Laptop", "Weekdays");
        gadgetsList.AddGadget("Gym Bag", "Gym Days");
        gadgetsList.AddGadget("Wallet", "Everyday");

        // Display all gadgets
        Console.WriteLine("All Gadgets:");
        gadgetsList.DisplayAllGadgets();

        // Display gadgets for Weekdays
        Console.WriteLine("\nWeekdays Gadgets:");
        gadgetsList.DisplayGadgetsByDay("Weekdays");

        // Count gadgets
        Console.WriteLine($"\nTotal Gadgets: {gadgetsList.CountGadgets()}");

        // Remove a gadget
        gadgetsList.RemoveGadget("Laptop");
        Console.WriteLine("\nAfter removing Laptop:");
        gadgetsList.DisplayAllGadgets();

        // Reverse the list
        gadgetsList.ReverseList();
        Console.WriteLine("\nReversed Gadgets List:");
        gadgetsList.DisplayAllGadgets();

        // Insert a gadget at a specific position
        gadgetsList.InsertGadgetAt(2, "Tablet", "Weekend");
        Console.WriteLine("\nAfter inserting Tablet at position 2:");
        gadgetsList.DisplayAllGadgets();
    }
}
