﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace EDCGadgetsLinkedList
{
    public class LinkedListNode
    {
        public string Gadget { get; set; }
        public string DaysOfTheWeek { get; set; } // e.g., "Everyday", "Weekdays", "Gym Days", etc.
        public LinkedListNode Next { get; set; }
        public LinkedListNode Previous { get; set; }

        public LinkedListNode(string gadget, string daysOfTheWeek)
        {
            Gadget = gadget;
            DaysOfTheWeek = daysOfTheWeek;
            Next = null;
            Previous = null;
        }
    }
}
