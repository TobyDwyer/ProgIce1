﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDCGadgetsLinkedList
{
    public class CustomLinkedList
    {
        private LinkedListNode head;
        private LinkedListNode tail;

        public CustomLinkedList()
        {
            head = null;
            tail = null;
        }

        // Add a new gadget at the end of the list
        public void AddGadget(string gadget, string daysOfTheWeek)
        {
            LinkedListNode newNode = new LinkedListNode(gadget, daysOfTheWeek);
            if (head == null)
            {
                head = tail = newNode;
            }
            else
            {
                tail.Next = newNode;
                newNode.Previous = tail;
                tail = newNode;
            }
        }

        // Remove a gadget by name
        public void RemoveGadget(string gadget)
        {
            LinkedListNode current = head;
            while (current != null)
            {
                if (current.Gadget == gadget)
                {
                    if (current == head)
                    {
                        head = current.Next;
                    }
                    if (current == tail)
                    {
                        tail = current.Previous;
                    }
                    if (current.Previous != null)
                    {
                        current.Previous.Next = current.Next;
                    }
                    if (current.Next != null)
                    {
                        current.Next.Previous = current.Previous;
                    }
                    break;
                }
                current = current.Next;
            }
        }

        // Find a gadget in the list
        public LinkedListNode FindGadget(string gadget)
        {
            LinkedListNode current = head;
            while (current != null)
            {
                if (current.Gadget == gadget)
                {
                    return current;
                }
                current = current.Next;
            }
            return null;
        }

        // Count the number of gadgets in the list
        public int CountGadgets()
        {
            int count = 0;
            LinkedListNode current = head;
            while (current != null)
            {
                count++;
                current = current.Next;
            }
            return count;
        }

        // Insert a gadget at a specific position
        public void InsertGadgetAt(int position, string gadget, string daysOfTheWeek)
        {
            if (position < 0 || position > CountGadgets())
            {
                throw new ArgumentOutOfRangeException(nameof(position), "Position out of range");
            }

            LinkedListNode newNode = new LinkedListNode(gadget, daysOfTheWeek);
            if (position == 0)
            {
                newNode.Next = head;
                if (head != null)
                {
                    head.Previous = newNode;
                }
                head = newNode;
                if (tail == null)
                {
                    tail = newNode;
                }
                return;
            }

            LinkedListNode current = head;
            for (int i = 0; i < position - 1; i++)
            {
                current = current.Next;
            }

            newNode.Next = current.Next;
            newNode.Previous = current;
            if (current.Next != null)
            {
                current.Next.Previous = newNode;
            }
            current.Next = newNode;

            if (newNode.Next == null)
            {
                tail = newNode;
            }
        }

        // Reverse the linked list
        public void ReverseList()
        {
            LinkedListNode current = head;
            LinkedListNode temp = null;

            while (current != null)
            {
                temp = current.Previous;
                current.Previous = current.Next;
                current.Next = temp;
                current = current.Previous;
            }

            if (temp != null)
            {
                head = temp.Previous;
            }
        }

        // Clear the entire list
        public void ClearList()
        {
            head = tail = null;
        }

        // Display all gadgets
        public void DisplayAllGadgets()
        {
            LinkedListNode current = head;
            while (current != null)
            {
                Console.WriteLine($"{current.Gadget} - {current.DaysOfTheWeek}");
                current = current.Next;
            }
        }

        // Display gadgets based on the day of the week
        public void DisplayGadgetsByDay(string day)
        {
            LinkedListNode current = head;
            while (current != null)
            {
                if (current.DaysOfTheWeek.Contains(day) || current.DaysOfTheWeek == "Everyday")
                {
                    Console.WriteLine($"{current.Gadget} - {current.DaysOfTheWeek}");
                }
                current = current.Next;
            }
        }
    }
}
